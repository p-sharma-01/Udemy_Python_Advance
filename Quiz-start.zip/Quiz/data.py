question_data = [
    {
        "question": "Adolf Hitler was born in Australia. ",
        "correct_answer": "False",
    },
    {
        "question": "The National Animal of Scotland is the Unicorn.",
        "correct_answer": "True",
    },
    {
        "question": "It is automatically considered entrapment in the United States "
                    "if the police sell you illegal"
                    " substances without revealing themselves.",
        "correct_answer": "False",
    },
    {
        "question": "The color orange is named after the fruit.",
        "correct_answer": "True",
    },
    {
        "question": "Pluto is a planet.",
        "correct_answer": "False",
    },
    {
        "question": "The Lego Group was founded in 1932.",
        "correct_answer": "True",
    },
    {
        "question": "Dihydrogen Monoxide was banned due to health risks after being "
                    "discovered in 1983 "
                    "inside swimming pools and drinking water.",
        "correct_answer": "False",
    },
    {
        "question": "In 2010, Twitter and the United States Library of Congress partnered "
                    "together to archive every tweet by American citizens.",
        "correct_answer": "True",
    },
    {
        "question": "&quot;Ananas&quot; is mostly used as the word for Pineapple in other "
                    "languages.",
        "correct_answer": "True",
    },
    {
        "question": "Scotland voted to become an independent country during the referendum from "
                    "September 2014.",
        "correct_answer": "False",
    }
]
